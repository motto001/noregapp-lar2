<?php

return [

    'cors' => env('CORS', false),
];