<div class="form-group <?php echo e($errors->has('worker_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('worker_id', 'Worker Id', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('worker_id', 0, ['class' => 'form-control']); ?>

        <?php echo $errors->first('worker_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('year') ? 'has-error' : ''); ?>">
    <?php echo Form::label('year', 'Year', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('year', 0000, ['class' => 'form-control']); ?>

        <?php echo $errors->first('year', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('mounth') ? 'has-error' : ''); ?>">
    <?php echo Form::label('mounth', 'Mounth', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('mounth', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('mounth', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('day') ? 'has-error' : ''); ?>">
    <?php echo Form::label('day', 'Day', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('day', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('day', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('type') ? 'has-error' : ''); ?>">
    <?php echo Form::label('type', 'Type', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('type', ['normal', 'ünnep', 'szabadság', 'igazolt', 'beteg'], null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('type', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
