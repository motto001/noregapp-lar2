 
 <?php $__env->startSection('subcontent'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-8">
                <div class="panel panel-default">
                    <div class="panel-heading"><h3>Munkaidő felvitele: 
                   <span style="color:blue;"> <?php echo e($data['username']); ?> </span>
                    <?php echo e($data['year']); ?>-<?php echo e($data['month']); ?>-<?php echo e($data['day']); ?></h3>
                    
               
                    
                    </div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('workadmin/workerdays/'.$data['year'].'/'.$data['month'].'/0/'.$data['userid'])); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <?php echo $__env->make('workadmin.workerdays.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--/'.$data['year'].'/'.$data['month'].'/'.$data['day'].'/'.$data['userid'], 'class' => '', 'files' => true]-->
                        <?php echo Form::open(['url' => 'workadmin/workerdays/store']); ?>


                        <?php echo $__env->make('workadmin.workerdays.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('workadmin.workerdays.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>