<div class="form-group <?php echo e($errors->has('worker_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('worker_id', 'Worker Id', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('worker_id', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('worker_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('date') ? 'has-error' : ''); ?>">
    <?php echo Form::label('date', 'Date', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::date('date', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('date', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('start') ? 'has-error' : ''); ?>">
    <?php echo Form::label('start', 'Start', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::input('time', 'start', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('start', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('end') ? 'has-error' : ''); ?>">
    <?php echo Form::label('end', 'End', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::input('time', 'end', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('end', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('hour') ? 'has-error' : ''); ?>">
    <?php echo Form::label('hour', 'Hour', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('hour', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('hour', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('type') ? 'has-error' : ''); ?>">
    <?php echo Form::label('type', 'Type', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('type', ['normal', 'plusz', 'ledolg'], null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('type', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
