 
<?php $__env->startSection('content'); ?>
<style>
.weekness{
color:red;
border: 1px solid red; 
}
.workday{
color:silver;
border: 1px solid silver; 
}
.flex-container {
    padding: 0;
    margin: 0;
    list-style: none;
    justify-content:flex-end;
    -ms-box-orient: horizontal;
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -moz-flex;
    display: -webkit-flex;
    display: flex;
  }
  
  .nowrap  { 
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
  }
  

  
  .flex-item { 
    background: white;
    padding: 5px;
    width: 13.7%;
   /* height: 100px;*/
    margin: 0.3%;
    text-align: center;
    overflow:hidden;
  }
</style>
<div class="container">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">Munkaidő</div>
                <div class="panel-body">


                

                        <?php $__currentLoopData = $data['months']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/worker/worktimes/'.$data['year'].'/'.$mt['id'].'/'.$data['day'].'/'.$data['userid'])); ?>">
                            <button class="<?php echo e($mt['class']); ?>">
                                        
                                            <div><?php echo e($mt['name']); ?></div>
                        
                            </button>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<hr>                        
                        <div style="clear:both"></div>
                       <?php echo $__env->yieldContent('subcontent'); ?>
                     
                     

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>