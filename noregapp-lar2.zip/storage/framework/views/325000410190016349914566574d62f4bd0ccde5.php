<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::email('email', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('password', 'Jelszó', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('password', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('name', 'Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('cim') ? 'has-error' : ''); ?>">
    <?php echo Form::label('cim', 'Cim', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('cim', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('cim', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('tel') ? 'has-error' : ''); ?>">
    <?php echo Form::label('tel', 'Tel', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('tel', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('tel', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('birth') ? 'has-error' : ''); ?>">
    <?php echo Form::label('birth', 'Birth', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::date('birth', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('birth', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('ado') ? 'has-error' : ''); ?>">
    <?php echo Form::label('ado', 'Ado', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('ado', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('ado', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('tb') ? 'has-error' : ''); ?>">
    <?php echo Form::label('tb', 'Tb', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('tb', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('tb', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('start') ? 'has-error' : ''); ?>">
    <?php echo Form::label('start', 'Start', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::date('start', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('start', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('end') ? 'has-error' : ''); ?>">
    <?php echo Form::label('end', 'End', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::date('end', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('end', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('statusz') ? 'has-error' : ''); ?>">
    <?php echo Form::label('statusz', 'Statusz', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('statusz', ['Állandó', 'alkalmi', 'diák'], null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('statusz', '<p class="help-block">:message</p>'); ?>

  
    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
