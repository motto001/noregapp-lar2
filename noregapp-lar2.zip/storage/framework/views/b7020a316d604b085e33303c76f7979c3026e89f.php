 
 <?php $__env->startSection('subcontent'); ?>
 <ul class="flex-container nowrap">
                            <li class="flex-item "  style="height:40px">Hétfő</li>
                            <li class="flex-item "  style="height:40px">Kedd</li>
                            <li class="flex-item "  style="height:40px">Szerda</li>
                            <li class="flex-item "  style="height:40px">Csütörtök</li>
                            <li class="flex-item "  style="height:40px">Péntek</li>
                            <li class="flex-item "  style="height:40px; color:red;">Szombat</li>
                            <li class="flex-item "  style="height:40px;color:red;">Vasárnap</li>

                        </ul>
                        <?php $__currentLoopData = $data['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                             <?php if($dt['weeknum']==1 || $dt['date']==1): ?>
                             <ul class="flex-container nowrap" 
                             <?php if($dt['date']>21): ?>
                             style="justify-content:flex-start"
                              <?php endif; ?>
                             >
                             <?php endif; ?>
                                
                               
                                    <li class="flex-item <?php echo e($dt['class']); ?>"
                                    
                                    <?php if($dt['date']==$data['day']): ?>
                                    style="border-color:blue;"
                                    <?php endif; ?>
                                    
                                    >
                                     
                                

                                        <span><?php echo e($dt['date']); ?></span>
                            <div style="display: flex;width:100%;justify-content:flex-end;border: 1px solid silver; ">            
                            <a href="<?php echo e(url('/manager/workerusers/')); ?>" 
                            title="View Workeruser"><button class="btn btn-info btn-xs">
                            <i class="fa fa-eye" aria-hidden="true"></i> </button>
                            </a>
                            <span 
                             title="Edit Workeruser"><button class="btn btn-primary btn-xs"
                            <?php if($data['userid']>0): ?> 
                              onClick="javascript:window.location.href='/worker/worktimes/create/<?php echo e($data['year']); ?>/<?php echo e($data['month']); ?>/<?php echo e($dt['date']); ?>/<?php echo e($data['userid']); ?>'" 
                            <?php else: ?>
                                onClick="alert('Ki kell jelölni egy hónapot')"
                            <?php endif; ?>
                             >
                             <i class="fa fa-pencil-square-o" aria-hidden="true">szerk</i></button>
                             </span>
                             </div> 
                                        
                                    </li>
                                
                            <?php if($dt['weeknum']==0 ): ?>
                            </ul >
                            <?php endif; ?>
                                
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>                        
<?php echo $__env->make('worker.worktimes.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>