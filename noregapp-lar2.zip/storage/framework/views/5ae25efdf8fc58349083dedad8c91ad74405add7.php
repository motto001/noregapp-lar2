 
<?php $__env->startSection('content'); ?>
<style>
.weekness{
color:red;
border: 1px solid red; 
}
.workday{
color:silver;
border: 1px solid silver; 
}
.flex-container {
    padding: 0;
    margin: 0;
    list-style: none;
    justify-content:flex-end;
    -ms-box-orient: horizontal;
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -moz-flex;
    display: -webkit-flex;
    display: flex;
  }
  
  .nowrap  { 
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
  }
  

  
  .flex-item { 
    background: white;
    padding: 5px;
    width: 13.7%;
   /* height: 100px;*/
    margin: 0.3%;
    text-align: center;
    overflow:hidden;
  }
</style>
<div class="container">
    <div class="row">
        <?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">Workerusersdays</div>
                <div class="panel-body">


                    <?php echo Form::open(['method' => 'GET', 'url' => '/manager/workerusers/'.$data['year'].'/'.$data['month'].'/'.$data['day'].'/'.$data['userid'], 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="Search...">
                        <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                        </span>
                    </div>
                    <?php echo Form::close(); ?>


            
                    <ul class="flex-container nowrap"  style="justify-content:flex-start"> 

                        <?php $__currentLoopData = $data['workerusers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
   
                                <li class="flex-item " style="width:20%;border: 1px solid 
                             <?php if($data['userid']==$item->user_id ): ?>
                                red
                                <?php else: ?>
                                silver
                                <?php endif; ?>
                                 " >

                                    <span><?php echo e($item->user_id); ?> </span>
                                    <div> <?php echo e($item->user->name); ?></div>
                                    <div style="display: flex;width:100%;justify-content:flex-end; ">            
                                        <a href="<?php echo e(url('/manager/workerusers/' . $item->id)); ?>" 
                                        title="View Workeruser"><button class="btn btn-info btn-xs">
                                        <i class="fa fa-eye" aria-hidden="true"></i> </button>
                                        </a>
                                        <a href="<?php echo e(url('/workadmin/workerdays/'.$data['year'].'/'.$data['month'].'/'.$data['day'].'/'.$item->user_id)); ?>"
                                        title="Edit Workeruser"><button class="btn btn-primary btn-xs">
                                        <i class="fa fa-checked" aria-hidden="true">Kijelöl</i></button>
                                        </a>
                                    </div>            
                                </li>       
 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>

                        <div style="clear: both;"></div>
                        <div class="pagination-wrapper"> <?php echo $data['workerusers']->appends(['search' => Request::get('search')])->render(); ?></div>
                        <?php $__currentLoopData = $data['months']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/workadmin/workerdays/'.$data['year'].'/'.$mt['id'].'/'.$data['day'].'/'.$data['userid'])); ?>">
                            <button class="<?php echo e($mt['class']); ?>">
                                        
                                            <div><?php echo e($mt['name']); ?></div>
                        
                            </button>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<hr>                        
                        <div style="clear:both"></div>
                       <?php echo $__env->yieldContent('subcontent'); ?>
                     
                     

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>