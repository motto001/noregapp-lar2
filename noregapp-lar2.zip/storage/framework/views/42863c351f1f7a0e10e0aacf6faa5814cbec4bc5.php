<div class="col-md-3">

 
            <div class="panel panel-default panel-flush">
                <div class="panel-heading">
                  Menü
                </div>

                <div class="panel-body">
                    <ul class="nav" role="tablist">
 <?php if(Auth::user()->hasRole('workadmin')): ?>                 
                    
 <li role="manager">
                                <a href="<?php echo e(url('/workadmin/workerdays')); ?>">
                                    Munkaidő
                                </a>
                            </li>






                            
<?php elseif(Auth::user()->hasRole('worker')): ?>
<li role="admin">
                                <a href="<?php echo e(url('/user/personal')); ?>">
                                   Személyes adatok
                                </a>
                            </li>

                             <li role="admin">
                                <a href="<?php echo e(url('/user/worktime')); ?>">
                                   Munkaidő
                                </a>
                            </li>

 <?php endif; ?>
 <?php if(Auth::user()->hasRole('manager')): ?>  
                            <li role="manager">
                                <a href="<?php echo e(url('/manager/workerusers')); ?>">
                                    Dolgozok
                                </a>
                            </li>
                              <li role="manager">
                                <a href="<?php echo e(url('/manager/users')); ?>">
                                    Felhasználók
                                </a>
                            </li>

<?php elseif(Auth::user()->hasRole('workadmin')): ?>
                        <li role="manager">
                                <a href="<?php echo e(url('/workadmin/workers')); ?>">
                                    Dolgozok
                                </a>
                            </li>

 <?php endif; ?>
 <?php if(Auth::user()->hasRole('workadmin')): ?>  
                           
                            <li role="manager">
                                <a href="<?php echo e(url('/workadmin/days')); ?>">
                                    Napok
                                </a>
                            </li>
                     
                         
 <?php endif; ?>




 <?php if(Auth::user()->hasRole('admin')): ?>                     
                            <li role="root">
                                <a href="<?php echo e(url('/admin/roles')); ?>">
                                    Jogok
                                </a>
                            </li>
                            <li role="root">
                                <a href="<?php echo e(url('/admin/permissions')); ?>">
                                    Szabályok
                                </a>
                            </li>
                            <li role="root">
                                <a href="<?php echo e(url('/admin/give-role-permissions')); ?>">
                                   Give role-permissions
                                </a>
                            </li>

 <?php endif; ?>
         
           <li role="user">
                                <a href="<?php echo e(url('/user/chpassword')); ?>">
                                   Password
                                </a>
                            </li>              

                    </ul>
                </div>
            </div>


       <?php if(Auth::user()->hasRole('admin')): ?>  
            <div class="panel panel-default panel-flush">
                <div class="panel-heading">
                    Tools
                </div>

                <div class="panel-body">
                    <ul class="nav" role="tablist">
                      
                            <li role="admin">
                                <a href="<?php echo e(url('/admin/generator')); ?>">
                                    Generator
                                </a>
                            </li>
                        
                    </ul>
                </div>
            </div>
        <?php endif; ?>

</div>

