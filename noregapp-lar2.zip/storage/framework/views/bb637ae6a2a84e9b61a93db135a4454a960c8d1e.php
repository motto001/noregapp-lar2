

    
        <?php echo Form::hidden('worker_id', $data['userid'], ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('worker_id', '<p class="help-block">:message</p>'); ?>


  
        <?php echo Form::hidden('date', $data['year'].':'.$data['month'].':'.$data['day'], ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('date', '<p class="help-block">:message</p>'); ?>


<span class="form-group <?php echo e($errors->has('start') ? 'has-error' : ''); ?>">
    <?php echo Form::label('start', 'Start', ['class' => 'col-md-1 control-label']); ?>

    <div class="col-md-2">
        <?php echo Form::input('time', 'start', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('start', '<p class="help-block">:message</p>'); ?>

    </div>
</span><span class="form-group <?php echo e($errors->has('end') ? 'has-error' : ''); ?>">
    <?php echo Form::label('end', 'End', ['class' => 'col-md-1 control-label']); ?>

    <div class="col-md-2">
        <?php echo Form::input('time', 'end', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('end', '<p class="help-block">:message</p>'); ?>

    </div>
</span><div class="form-group <?php echo e($errors->has('hour') ? 'has-error' : ''); ?>">
    <?php echo Form::label('hour', 'Hour', ['class' => 'col-md-1 control-label']); ?>

    <div class="col-md-2">
        <?php echo Form::number('hour', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('hour', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('type') ? 'has-error' : ''); ?>">
   
    <div class="col-md-3">
    <select class="form-control" required="required" name="type">
        <option value="normal">normal</option>
        <option value="plusz">plusz</option>
        <option value="ledolg">ledolg</option>
    </select>   
    </div>





</div>
</br></br>
<div class="form-group">
    <div class="col-md-offset-8 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
